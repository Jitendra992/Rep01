# Front Desk – Visitor Meeting Routing

Reception checks visitors in and routes them to the MD, COO or President, who accept, decline, hold or (MD only) transfer the request. Reception sees the answer live.

## Run locally

```bash
npm install
npm run dev        # development
npm run build      # production build into dist/
npm run preview    # serve the production build
```

Open two tabs: log in as Receptionist in one and MD in the other. Sessions are per tab (sessionStorage); visitor data is shared (localStorage + BroadcastChannel). Demo password for all accounts: `password123`.

## Deploy to Vercel

Import the repo as a Vite project (build `npm run build`, output `dist`). `vercel.json` rewrites all paths to `index.html` so deep links like `/md` work. No environment variables are required.

## UI notes

- Design tokens (colour, surfaces, shadows) live as CSS variables in `src/index.css`; Tailwind maps them in `tailwind.config.js`.
- Light/dark theme: toggle in the top bar or account menu. The choice is stored in `localStorage` (`vmr.theme`) and defaults to the system setting.
- Glass effects fall back to solid surfaces when `backdrop-filter` is unsupported or reduced transparency is requested.
- Shortcuts: `Ctrl/⌘ + K` opens quick search and actions, `/` focuses the page search, `Esc` closes dialogs and menus.
- Other UI preferences stored locally: sidebar collapsed state (`vmr.ui.sidebar`) and the dismissed tip (`vmr.ui.hint.v1`).
- All figures on the dashboards are computed from the stored visitor records. Nothing is simulated.

## Security note

Authentication is a client-side demo (users and passwords are in `src/types/index.js`). It is not suitable for real access control; replace it with a server-side auth service before production use.
