import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Building2, ChevronRight, ChevronsLeft, ChevronsRight, Menu, Search, X } from 'lucide-react';
import Avatar from './Avatar';
import CommandPalette from './CommandPalette';
import NotificationMenu from './NotificationMenu';
import OnboardingHint from './OnboardingHint';
import ThemeToggle from './ThemeToggle';
import UserMenu from './UserMenu';
import { useAuth } from '../context/AuthContext';
import useStoredFlag from '../hooks/useStoredFlag';
import { modKey, scrollToSection } from '../lib/nav';
import { ROLE_LABEL, ROLE_PATH } from '../types';

const isEditable = (el) =>
  !!el && (['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName) || el.isContentEditable);

/**
 * Application shell: collapsible sidebar (drawer on mobile), top bar with breadcrumbs,
 * search, notifications, theme and account menu.
 * `nav` must be a stable array: [{ id, label, icon }] where id is an in-page section id.
 */
export default function AppShell({ crumb, nav, listSectionId, children }) {
  const { user } = useAuth();
  const [collapsed, setCollapsed] = useStoredFlag('vmr.ui.sidebar', false);
  const [drawer, setDrawer] = useState(false);
  const [palette, setPalette] = useState(false);
  const [active, setActive] = useState(nav[0]?.id);

  // Highlight the section currently in view.
  useEffect(() => {
    const els = nav.map((n) => document.getElementById(n.id)).filter(Boolean);
    if (!els.length || !('IntersectionObserver' in window)) return undefined;
    const io = new IntersectionObserver((entries) => {
      const top = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
      if (top) setActive(top.target.id);
    }, { rootMargin: '-20% 0px -60% 0px' });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, [nav]);

  // Global shortcuts: Ctrl/⌘+K opens the palette, "/" focuses the page search.
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette((o) => !o); return; }
      if (e.key === '/' && !e.metaKey && !e.ctrlKey && !e.altKey && !isEditable(e.target)) {
        const el = document.querySelector('[data-page-search]');
        if (el) { e.preventDefault(); el.focus(); }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    if (!drawer) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') setDrawer(false); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [drawer]);

  const go = (e, id) => { e.preventDefault(); setActive(id); setDrawer(false); scrollToSection(id); };
  const hide = collapsed ? 'lg:hidden' : '';

  return (
    <>
      <a href="#main" className="sr-only z-[80] rounded-lg bg-brand px-3 py-2 text-sm font-medium text-brand-fg focus:not-sr-only focus:fixed focus:left-3 focus:top-3">
        Skip to content
      </a>

      {drawer && <div aria-hidden="true" className="fixed inset-0 z-30 animate-fade-in bg-slate-950/50 lg:hidden" onClick={() => setDrawer(false)} />}

      <aside id="sidebar"
        className={`nav-shell fixed inset-y-0 left-0 z-40 flex w-72 flex-col transition-[width,transform,visibility] duration-200 lg:translate-x-0 ${collapsed ? 'lg:w-[4.75rem]' : 'lg:w-64'} ${drawer ? 'translate-x-0' : '-translate-x-full max-lg:invisible'}`}>
        <div className="flex h-16 items-center gap-3 px-5">
          <span aria-hidden="true" className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-400 to-indigo-600 text-white shadow-lg shadow-indigo-900/40">
            <Building2 className="h-5 w-5" />
          </span>
          <span className={`text-base font-semibold text-white ${hide}`}>Front Desk</span>
          <button type="button" onClick={() => setDrawer(false)} aria-label="Close navigation" className="ml-auto rounded p-1 text-slate-400 hover:text-white lg:hidden">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav aria-label="Sections" className="flex-1 space-y-1 px-3 py-3">
          {nav.map((n) => (
            <a key={n.id} href={`#${n.id}`} onClick={(e) => go(e, n.id)} aria-label={n.label}
              title={collapsed ? n.label : undefined} aria-current={active === n.id ? 'true' : undefined} className="nav-item">
              <n.icon className="h-[1.15rem] w-[1.15rem] shrink-0" aria-hidden="true" />
              <span className={hide}>{n.label}</span>
            </a>
          ))}
        </nav>

        <div className="space-y-2 border-t border-white/10 p-3">
          <div className={`flex items-center gap-3 rounded-lg px-2 py-2 ${hide}`}>
            <Avatar name={user.name} size="sm" />
            <div className="min-w-0 leading-tight">
              <p className="truncate text-sm font-medium text-white">{user.name}</p>
              <p className="text-xs text-slate-400">{ROLE_LABEL[user.role]}</p>
            </div>
          </div>
          <button type="button" onClick={() => setCollapsed(!collapsed)} aria-pressed={collapsed}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'} title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="nav-item hidden w-full lg:flex">
            {collapsed ? <ChevronsRight className="h-[1.15rem] w-[1.15rem]" aria-hidden="true" /> : <ChevronsLeft className="h-[1.15rem] w-[1.15rem]" aria-hidden="true" />}
            <span className={hide}>Collapse</span>
          </button>
        </div>
      </aside>

      <div className={`transition-[padding] duration-200 ${collapsed ? 'lg:pl-[4.75rem]' : 'lg:pl-64'}`}>
        <header className="glass sticky top-0 z-20 flex h-16 items-center gap-2 rounded-none border-x-0 border-t-0 px-3 sm:px-6">
          <button type="button" onClick={() => setDrawer(true)} aria-label="Open navigation" aria-expanded={drawer} aria-controls="sidebar" className="btn-icon lg:hidden">
            <Menu className="h-5 w-5" />
          </button>
          <nav aria-label="Breadcrumb" className="min-w-0 flex-1">
            <ol className="flex items-center gap-1.5 text-sm text-muted">
              <li className="hidden sm:block"><Link to={ROLE_PATH[user.role]} className="rounded hover:text-ink">Front Desk</Link></li>
              <li className="flex min-w-0 items-center gap-1.5">
                <ChevronRight className="hidden h-3.5 w-3.5 shrink-0 sm:block" aria-hidden="true" />
                <span aria-current="page" className="truncate font-medium text-ink">{crumb}</span>
              </li>
            </ol>
          </nav>
          <button type="button" onClick={() => setPalette(true)}
            className="hidden h-10 w-64 items-center gap-2 rounded-lg border border-line/30 bg-surface/50 px-3 text-sm text-muted transition-colors hover:bg-surface/90 md:flex lg:w-80">
            <Search className="h-4 w-4" aria-hidden="true" />
            <span className="flex-1 text-left">Search visitors and actions</span>
            <span aria-hidden="true" className="flex gap-1"><kbd className="kbd">{modKey}</kbd><kbd className="kbd">K</kbd></span>
            <span className="sr-only">Opens search ({modKey} K)</span>
          </button>
          <button type="button" onClick={() => setPalette(true)} aria-label="Search visitors and actions" className="btn-icon md:hidden">
            <Search className="h-[1.1rem] w-[1.1rem]" />
          </button>
          <NotificationMenu sectionId={listSectionId} />
          <ThemeToggle />
          <UserMenu />
        </header>

        <main id="main" tabIndex={-1} className="mx-auto w-full max-w-[84rem] px-4 py-6 focus:outline-none sm:px-6 lg:px-8">
          <OnboardingHint />
          {children}
        </main>
      </div>

      {palette && <CommandPalette onClose={() => setPalette(false)} sections={nav} listSectionId={listSectionId} />}
    </>
  );
}
