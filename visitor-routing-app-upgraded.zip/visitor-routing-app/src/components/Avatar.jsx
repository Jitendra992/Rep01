import { initials } from '../lib/format';

export default function Avatar({ name, size = 'md' }) {
  const dim = size === 'sm' ? 'h-8 w-8 text-xs' : 'h-9 w-9 text-sm';
  return (
    <span aria-hidden="true" className={`inline-flex ${dim} shrink-0 items-center justify-center rounded-full bg-brand/15 font-semibold text-brand`}>
      {initials(name)}
    </span>
  );
}
