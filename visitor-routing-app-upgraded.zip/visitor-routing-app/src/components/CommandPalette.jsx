import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useNavigate } from 'react-router-dom';
import { CornerDownLeft, LogOut, Moon, Search, Sun, UserRound } from 'lucide-react';
import { StatusBadge } from './StatusBadge';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useVisitors } from '../context/VisitorContext';
import { scrollToSection } from '../lib/nav';
import { ROLE_PATH, ROLES } from '../types';

/** Quick search + actions. Visitor results open the list filtered to that person. */
export default function CommandPalette({ onClose, sections, listSectionId }) {
  const { user, logout } = useAuth();
  const { visitors } = useVisitors();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [idx, setIdx] = useState(0);
  const listId = useId();
  const inputRef = useRef(null);

  useEffect(() => {
    const prev = document.activeElement;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    inputRef.current?.focus();
    return () => { document.body.style.overflow = prevOverflow; prev?.focus?.(); };
  }, []);

  const items = useMemo(() => {
    const term = q.trim().toLowerCase();
    const actions = [
      ...sections.map((s) => ({ id: `go-${s.id}`, group: 'Go to', label: s.label, icon: s.icon, run: () => scrollToSection(s.id) })),
      { id: 'theme', group: 'Preferences', label: `Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`, icon: theme === 'dark' ? Sun : Moon, run: toggle },
      { id: 'logout', group: 'Account', label: 'Log out', icon: LogOut, run: () => { logout(); navigate('/login'); } },
    ].filter((a) => !term || a.label.toLowerCase().includes(term));

    const mine = user.role === ROLES.RECEPTIONIST ? visitors : visitors.filter((v) => v.assignedTo === user.role);
    const people = term
      ? mine.filter((v) => [v.name, v.phone, v.agenda].some((s) => s.toLowerCase().includes(term))).slice(0, 6).map((v) => ({
        id: `v-${v.id}`, group: 'Visitors', label: v.name, sub: v.agenda, status: v.status, icon: UserRound,
        run: () => {
          navigate(`${ROLE_PATH[user.role]}?q=${encodeURIComponent(v.name)}`);
          setTimeout(() => scrollToSection(listSectionId), 60);
        },
      }))
      : [];
    return [...people, ...actions];
  }, [q, sections, theme, toggle, logout, navigate, user.role, visitors, listSectionId]);

  const active = Math.min(idx, Math.max(items.length - 1, 0));

  useEffect(() => {
    document.getElementById(`${listId}-${active}`)?.scrollIntoView({ block: 'nearest' });
  }, [active, listId]);

  const run = (item) => { onClose(); item.run(); };

  const onKeyDown = (e) => {
    if (e.key === 'Escape') { e.preventDefault(); onClose(); }
    else if (e.key === 'Tab') e.preventDefault();
    else if (e.key === 'ArrowDown') { e.preventDefault(); setIdx((active + 1) % Math.max(items.length, 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setIdx((active - 1 + items.length) % Math.max(items.length, 1)); }
    else if (e.key === 'Enter' && items[active]) { e.preventDefault(); run(items[active]); }
  };

  return createPortal(
    <div className="fixed inset-0 z-[60] flex animate-fade-in items-start justify-center bg-slate-950/50 p-3 pt-[12vh]"
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div role="dialog" aria-modal="true" aria-label="Command palette"
        className="glass-strong w-full max-w-lg animate-pop-in overflow-hidden rounded-2xl shadow-pop">
        <div className="flex items-center gap-3 border-b border-line/20 px-4">
          <Search className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
          <input ref={inputRef} value={q} onChange={(e) => { setQ(e.target.value); setIdx(0); }} onKeyDown={onKeyDown}
            role="combobox" aria-expanded="true" aria-controls={listId} aria-autocomplete="list"
            aria-activedescendant={items.length ? `${listId}-${active}` : undefined}
            aria-label="Search visitors and actions" placeholder="Search visitors or type an action"
            className="h-12 w-full bg-transparent text-sm text-ink placeholder:text-muted/80 focus:outline-none" />
          <kbd className="kbd">Esc</kbd>
        </div>
        <ul id={listId} role="listbox" aria-label="Results" className="max-h-80 overflow-y-auto p-2">
          {items.length === 0 && <li role="presentation" className="px-3 py-8 text-center text-sm text-muted">No results for “{q}”.</li>}
          {items.map((it, i) => (
            <li key={it.id} role="presentation">
              {(i === 0 || items[i - 1].group !== it.group) && (
                <p className="px-3 pb-1 pt-2 text-xs font-medium text-muted">{it.group}</p>
              )}
              <div id={`${listId}-${i}`} role="option" aria-selected={i === active}
                onMouseMove={() => setIdx(i)} onClick={() => run(it)}
                className={`flex cursor-pointer items-center gap-3 rounded-lg px-3 py-2 text-sm ${i === active ? 'bg-brand/15' : ''}`}>
                <it.icon className="h-4 w-4 shrink-0 text-muted" aria-hidden="true" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate">{it.label}</span>
                  {it.sub && <span className="block truncate text-xs text-muted">{it.sub}</span>}
                </span>
                {it.status && <StatusBadge status={it.status} />}
                {i === active && <CornerDownLeft className="h-3.5 w-3.5 text-muted" aria-hidden="true" />}
              </div>
            </li>
          ))}
        </ul>
        <p className="border-t border-line/20 px-4 py-2 text-xs text-muted">Use ↑ ↓ to move, Enter to select.</p>
      </div>
    </div>,
    document.body
  );
}
