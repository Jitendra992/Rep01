/**
 * Label + control + hint/error. Wire the control with
 * id={htmlFor}, aria-describedby={`${htmlFor}-msg`}, aria-invalid={!!error}.
 */
export default function Field({ label, htmlFor, required, hint, error, className = '', children }) {
  return (
    <div className={className}>
      <label htmlFor={htmlFor} className="mb-1.5 block text-sm font-medium">
        {label}
        {required && <span aria-hidden="true" className="ml-0.5 text-danger">*</span>}
      </label>
      {children}
      {(error || hint) && (
        <p id={`${htmlFor}-msg`} role={error ? 'alert' : undefined}
          className={`mt-1.5 text-xs ${error ? 'text-danger' : 'text-muted'}`}>
          {error || hint}
        </p>
      )}
    </div>
  );
}
