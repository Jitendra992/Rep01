import { useMemo, useState } from 'react';
import { Archive, CheckCircle2, Inbox, PauseCircle, ArrowRightLeft, Search, Users } from 'lucide-react';
import AppShell from './AppShell';
import EmptyState from './EmptyState';
import FilterChips from './FilterChips';
import PageHeader from './PageHeader';
import RecentActivity from './RecentActivity';
import RequestCard from './RequestCard';
import SearchInput from './SearchInput';
import StatCard from './StatCard';
import StatusBreakdown from './StatusBreakdown';
import { useVisitors } from '../context/VisitorContext';
import useQueryParam from '../hooks/useQueryParam';
import { ROLE_LABEL, STATUS } from '../types';

const NAV = [
  { id: 'queue', label: 'Waiting for you', icon: Inbox },
  { id: 'handled', label: 'Handled', icon: Archive },
];
const HANDLED_STEP = 6;

/** Shared layout for any host dashboard: open queue first, handled requests below. */
export default function HostQueue({ role, transferTargets = [] }) {
  const { visitors } = useVisitors();
  const [q, setQ] = useQueryParam('q');
  const [status, setStatus] = useState('all');
  const [shown, setShown] = useState(HANDLED_STEP);

  const mine = visitors.filter((v) => v.assignedTo === role);
  const open = mine.filter((v) => v.status !== STATUS.ACCEPTED && v.status !== STATUS.DECLINED);
  const done = mine.filter((v) => v.status === STATUS.ACCEPTED || v.status === STATUS.DECLINED);
  const fromOthers = open.filter((v) => v.transferredFrom && v.transferredFrom !== role).length;
  const onHold = open.filter((v) => v.status === STATUS.ON_HOLD).length;

  const term = q.trim().toLowerCase();
  const matches = (v) => !term || [v.name, v.phone, v.agenda].join(' ').toLowerCase().includes(term);
  const openShown = useMemo(
    () => open.filter((v) => (status === 'all' || v.status === status) && matches(v)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [open, status, term]
  );
  const doneShown = useMemo(
    () => done.filter(matches),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [done, term]
  );

  const chip = (value, label, count) => ({ value, label, count });
  const options = [
    chip('all', 'All', open.length),
    chip(STATUS.PENDING, 'Pending', open.filter((v) => v.status === STATUS.PENDING).length),
    chip(STATUS.ON_HOLD, 'On hold', onHold),
    chip(STATUS.TRANSFERRED, 'Transferred', open.filter((v) => v.status === STATUS.TRANSFERRED).length),
  ];

  return (
    <AppShell crumb={`${ROLE_LABEL[role]} queue`} nav={NAV} listSectionId="queue">
      <PageHeader
        title={`${ROLE_LABEL[role]} queue`}
        description={`${open.length} waiting. New requests appear here automatically, even across tabs.`}
      />

      <section aria-label="Summary" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Waiting for you" value={open.length} icon={Users} tone="brand" />
        <StatCard label="On hold" value={onHold} icon={PauseCircle} tone="warning" />
        <StatCard label="Transferred to you" value={fromOthers} icon={ArrowRightLeft} tone="info" />
        <StatCard label="Handled" value={done.length} icon={CheckCircle2} tone="success" />
      </section>

      <div className="mt-6 grid gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <div className="min-w-0 space-y-8">
          <section id="queue" tabIndex={-1} aria-labelledby="queue-h" className="scroll-mt-24 focus:outline-none">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <h2 id="queue-h" className="text-lg font-semibold">Waiting for you</h2>
              <SearchInput value={q} onChange={setQ} label="Search requests" placeholder="Search name, phone or agenda" />
            </div>
            <div className="mb-4"><FilterChips options={options} value={status} onChange={setStatus} label="Filter waiting requests by status" /></div>
            {open.length === 0 ? (
              <div className="panel"><EmptyState icon={Inbox} title="No visitors waiting">New requests appear here automatically.</EmptyState></div>
            ) : openShown.length === 0 ? (
              <div className="panel">
                <EmptyState icon={Search} title="No matching requests"
                  action={<button type="button" className="btn btn-outline" onClick={() => { setQ(''); setStatus('all'); }}>Clear search and filters</button>}>
                  Try a different name or status.
                </EmptyState>
              </div>
            ) : (
              <div className="grid gap-4 lg:grid-cols-2">
                {openShown.map((v) => <RequestCard key={v.id} visitor={v} role={role} transferTargets={transferTargets} />)}
              </div>
            )}
          </section>

          <section id="handled" tabIndex={-1} aria-labelledby="handled-h" className="scroll-mt-24 focus:outline-none">
            <h2 id="handled-h" className="mb-4 text-lg font-semibold">Handled <span className="text-sm font-normal text-muted tabular-nums">({done.length})</span></h2>
            {doneShown.length === 0 ? (
              <div className="panel"><EmptyState icon={Archive} title={done.length ? 'No matching handled requests' : 'Nothing handled yet'}>
                {done.length ? 'Try a different search.' : 'Accepted and declined visitors are listed here.'}</EmptyState></div>
            ) : (
              <>
                <div className="grid gap-4 lg:grid-cols-2">
                  {doneShown.slice(0, shown).map((v) => <RequestCard key={v.id} visitor={v} role={role} />)}
                </div>
                {doneShown.length > shown && (
                  <div className="mt-4 text-center">
                    <button type="button" className="btn btn-outline" onClick={() => setShown(shown + HANDLED_STEP)}>
                      Show more ({doneShown.length - shown} left)
                    </button>
                  </div>
                )}
              </>
            )}
          </section>
        </div>

        <aside aria-label="Insights" className="space-y-6">
          <StatusBreakdown visitors={mine} />
          <RecentActivity visitors={mine} />
        </aside>
      </div>
    </AppShell>
  );
}
