import { useCallback, useMemo, useRef, useState } from 'react';
import { Bell } from 'lucide-react';
import RelativeTime from './RelativeTime';
import { remarkFor } from './StatusBadge';
import { useAuth } from '../context/AuthContext';
import { useVisitors } from '../context/VisitorContext';
import useDismiss from '../hooks/useDismiss';
import { scrollToSection } from '../lib/nav';
import { ROLE_LABEL, ROLES, STATUS } from '../types';

const OPEN = [STATUS.PENDING, STATUS.ON_HOLD, STATUS.TRANSFERRED];
const MAX = 6;

/**
 * Derived from live visitor data (no separate notification store):
 * hosts see requests waiting on them, reception sees the latest host responses.
 */
export default function NotificationMenu({ sectionId }) {
  const { user } = useAuth();
  const { visitors } = useVisitors();
  const isHost = user.role !== ROLES.RECEPTIONIST;
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const close = useCallback(() => setOpen(false), []);
  useDismiss(ref, close, open);

  const items = useMemo(() => (isHost
    ? visitors.filter((v) => v.assignedTo === user.role && OPEN.includes(v.status))
    : [...visitors].filter((v) => v.status !== STATUS.PENDING).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))),
  [visitors, isHost, user.role]);

  const count = isHost ? items.length : 0;
  const title = isHost ? 'Waiting for you' : 'Latest host responses';

  return (
    <div ref={ref} className="sm:relative">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-haspopup="true"
        aria-label={isHost ? `Notifications, ${count} waiting` : 'Notifications'} className="btn-icon relative">
        <Bell className="h-[1.1rem] w-[1.1rem]" />
        {count > 0 && (
          <span aria-hidden="true" className="absolute right-1 top-1 flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-danger px-1 text-[10px] font-semibold text-onsolid">
            {count > 9 ? '9+' : count}
          </span>
        )}
      </button>
      {open && (
        <div className="glass-strong absolute top-full z-50 mt-2 animate-pop-in rounded-xl shadow-pop max-sm:inset-x-3 sm:right-0 sm:w-96">
          <p className="border-b border-line/20 px-4 py-3 text-sm font-semibold">{title}</p>
          {items.length === 0 ? (
            <p className="px-4 py-8 text-center text-sm text-muted">
              {isHost ? 'No visitors are waiting for you.' : 'No host has responded yet.'}
            </p>
          ) : (
            <ul className="max-h-80 divide-y divide-line/15 overflow-y-auto">
              {items.slice(0, MAX).map((v) => {
                const r = remarkFor(v);
                return (
                  <li key={v.id} className="px-4 py-3 text-sm">
                    <p className="font-medium">{v.name}</p>
                    <p className="truncate text-muted">
                      {isHost
                        ? (v.transferredFrom && v.transferredFrom !== user.role ? `Transferred from ${ROLE_LABEL[v.transferredFrom]}` : v.agenda)
                        : `${r.strong ? `${r.strong}. ` : ''}${r.text}`}
                    </p>
                    <p className="mt-0.5 text-xs text-muted"><RelativeTime iso={isHost ? v.createdAt : v.updatedAt} /></p>
                  </li>
                );
              })}
            </ul>
          )}
          <div className="flex items-center justify-between border-t border-line/20 px-4 py-2.5 text-xs text-muted">
            <span>{items.length > MAX ? `+${items.length - MAX} more` : `${items.length} shown`}</span>
            <button type="button" className="font-medium text-brand hover:underline"
              onClick={() => { close(); scrollToSection(sectionId); }}>
              {isHost ? 'Go to queue' : 'Go to live board'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
