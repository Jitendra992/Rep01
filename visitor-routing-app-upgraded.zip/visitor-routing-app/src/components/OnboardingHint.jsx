import { Keyboard, X } from 'lucide-react';
import useStoredFlag from '../hooks/useStoredFlag';
import { modKey } from '../lib/nav';

/** One-time tip about the shortcuts that exist in this app. Dismissal is remembered. */
export default function OnboardingHint() {
  const [dismissed, setDismissed] = useStoredFlag('vmr.ui.hint.v1', false);
  if (dismissed) return null;
  return (
    <div role="note" className="panel mb-6 flex items-start gap-3 p-4">
      <Keyboard className="mt-0.5 h-5 w-5 shrink-0 text-brand" aria-hidden="true" />
      <div className="flex-1 text-sm">
        <p className="font-medium">Work faster with the keyboard</p>
        <p className="mt-0.5 text-muted">
          Press <kbd className="kbd">{modKey}</kbd> <kbd className="kbd">K</kbd> to search visitors and jump to any section,
          or <kbd className="kbd">/</kbd> to search the list on this page.
        </p>
      </div>
      <button type="button" onClick={() => setDismissed(true)} aria-label="Dismiss tip" className="rounded p-1 text-muted hover:text-ink">
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}
