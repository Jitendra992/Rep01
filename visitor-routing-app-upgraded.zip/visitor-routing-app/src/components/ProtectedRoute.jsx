import { Link, Navigate } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ROLE_PATH } from '../types';

/** Gate a route by role. Anonymous → /login. Wrong role → warning with link to own dashboard. */
export default function ProtectedRoute({ roles, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (!roles.includes(user.role)) {
    return (
      <main className="flex min-h-screen items-center justify-center p-4">
        <div className="panel w-full max-w-md p-8 text-center">
          <ShieldAlert className="mx-auto mb-3 h-10 w-10 text-danger" aria-hidden="true" />
          <h1 className="text-lg font-semibold">You can’t open this dashboard</h1>
          <p className="mt-1 text-sm text-muted">Your role doesn’t have access to this page.</p>
          <Link to={ROLE_PATH[user.role]} className="btn btn-primary mt-5">Go to my dashboard</Link>
        </div>
      </main>
    );
  }
  return children;
}
