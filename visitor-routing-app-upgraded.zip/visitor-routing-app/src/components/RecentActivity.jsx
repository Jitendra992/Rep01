import { useId, useMemo } from 'react';
import { Activity } from 'lucide-react';
import RelativeTime from './RelativeTime';
import { ROLE_LABEL } from '../types';

/** Latest events from the real visitor history. */
export default function RecentActivity({ visitors, limit = 6 }) {
  const id = useId();
  const events = useMemo(
    () => visitors
      .flatMap((v) => v.history.map((h, i) => ({ ...h, key: `${v.id}-${i}`, visitor: v.name })))
      .sort((a, b) => b.at.localeCompare(a.at))
      .slice(0, limit),
    [visitors, limit]
  );

  return (
    <section aria-labelledby={id} className="panel p-5">
      <h2 id={id} className="flex items-center gap-2 text-sm font-semibold">
        <Activity className="h-4 w-4 text-muted" aria-hidden="true" /> Recent activity
      </h2>
      {events.length === 0 ? (
        <p className="mt-3 text-sm text-muted">Check-ins and host responses will be listed here.</p>
      ) : (
        <ol className="mt-4 space-y-3">
          {events.map((e) => (
            <li key={e.key} className="text-sm">
              <p><span className="font-medium">{e.visitor}</span> <span className="text-muted">{e.action.toLowerCase()}</span></p>
              <p className="text-xs text-muted">by {ROLE_LABEL[e.by] || e.by}, <RelativeTime iso={e.at} /></p>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}
