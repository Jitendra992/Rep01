import { useEffect, useState } from 'react';
import { fmtTime } from '../types';
import { timeAgo } from '../lib/format';

/** "5 min ago" that keeps itself fresh; exact time on hover and in the dateTime attribute. */
export default function RelativeTime({ iso }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);
  return <time dateTime={iso} title={fmtTime(iso)}>{timeAgo(iso, now)}</time>;
}
