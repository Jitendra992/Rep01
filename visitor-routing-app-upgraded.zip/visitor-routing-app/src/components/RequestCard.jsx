import { useState } from 'react';
import { ArrowRightLeft, Check, Clock, History, Pause, Phone, X } from 'lucide-react';
import Avatar from './Avatar';
import Field from './Field';
import Modal from './Modal';
import RelativeTime from './RelativeTime';
import VisitorDetails from './VisitorDetails';
import { StatusBadge } from './StatusBadge';
import { useToast } from '../context/ToastContext';
import { useVisitors } from '../context/VisitorContext';
import { HOLD_OPTIONS, ROLE_LABEL, STATUS } from '../types';

const HOLD_LABEL = { '15m': '15 min', '30m': '30 min', '1h': '1 hour', custom: 'Custom note' };

/**
 * One visitor request for a host. Handles Accept / Decline / Hold,
 * plus Transfer when `transferTargets` is provided (MD only).
 */
export default function RequestCard({ visitor: v, role, transferTargets = [] }) {
  const { accept, decline, hold, transfer } = useVisitors();
  const toast = useToast();
  const [modal, setModal] = useState(null);
  const [text, setText] = useState('');
  const [duration, setDuration] = useState('30m');
  const [target, setTarget] = useState(transferTargets[0]);

  const openModal = (m) => { setText(''); setModal(m); };
  const close = () => setModal(null);
  const resolved = v.status === STATUS.ACCEPTED || v.status === STATUS.DECLINED;
  const fromTransfer = v.transferredFrom && v.transferredFrom !== role;

  const onAccept = () => { accept(v.id, role); toast.success(`${v.name} accepted. Reception can send them in.`); };
  const onDecline = (e) => {
    e.preventDefault();
    decline(v.id, role, text.trim());
    toast.info(`${v.name} declined.`);
    close();
  };
  const onHold = (e) => {
    e.preventDefault();
    const label = duration === 'custom' ? text.trim() : duration;
    hold(v.id, role, label);
    toast.success(`${v.name} put on hold: ${label}.`);
    close();
  };
  const onTransfer = (e) => {
    e.preventDefault();
    transfer(v.id, role, target, text.trim());
    toast.success(`${v.name} transferred to ${ROLE_LABEL[target]}.`);
    close();
  };

  return (
    <article className={`panel overflow-hidden ${fromTransfer ? 'ring-1 ring-info/50' : ''}`}>
      {fromTransfer && (
        <div className="border-b border-info/25 bg-info/10 px-4 py-2 text-sm text-info">
          <p className="flex items-center gap-1.5 font-semibold">
            <ArrowRightLeft className="h-4 w-4" aria-hidden="true" /> Transferred from {ROLE_LABEL[v.transferredFrom]}
          </p>
          {v.transferNote && <p className="mt-0.5">{ROLE_LABEL[v.transferredFrom]}’s note: “{v.transferNote}”</p>}
        </div>
      )}
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <Avatar name={v.name} />
            <div className="min-w-0">
              <h3 className="truncate font-semibold">{v.name}</h3>
              <p className="mt-0.5 flex items-center gap-1 text-sm text-muted"><Phone className="h-3.5 w-3.5" aria-hidden="true" />{v.phone}</p>
            </div>
          </div>
          <StatusBadge status={v.status} />
        </div>
        <p className="mt-3 text-sm">{v.agenda}</p>
        <p className="mt-2 flex items-center gap-1 text-xs text-muted">
          <Clock className="h-3.5 w-3.5" aria-hidden="true" />
          {resolved ? 'Checked in ' : 'Waiting since '}<RelativeTime iso={v.createdAt} />
        </p>
        {v.status === STATUS.ON_HOLD && (
          <p className="mt-2 rounded-lg bg-warning/15 px-3 py-1.5 text-sm text-warning">On hold: {v.remarks}</p>
        )}
        {v.status === STATUS.DECLINED && (
          <p className="mt-2 rounded-lg bg-danger/10 px-3 py-1.5 text-sm text-danger">Reason: {v.remarks}</p>
        )}

        <div className="mt-4 flex flex-wrap items-center gap-2">
          {!resolved && (
            <>
              <button type="button" onClick={onAccept} className="btn btn-success"><Check className="h-4 w-4" />Accept</button>
              <button type="button" onClick={() => openModal('decline')} className="btn btn-soft-danger"><X className="h-4 w-4" />Decline</button>
              <button type="button" onClick={() => openModal('hold')} className="btn btn-soft-warning"><Pause className="h-4 w-4" />Hold</button>
              {transferTargets.length > 0 && (
                <button type="button" onClick={() => openModal('transfer')} className="btn btn-soft-info"><ArrowRightLeft className="h-4 w-4" />Transfer</button>
              )}
            </>
          )}
          <button type="button" onClick={() => setModal('details')} className="btn btn-ghost ml-auto" aria-label={`View history for ${v.name}`}>
            <History className="h-4 w-4" />History
          </button>
        </div>
      </div>

      {modal === 'details' && <VisitorDetails id={v.id} onClose={close} />}

      {modal === 'decline' && (
        <Modal title={`Decline ${v.name}`} onClose={close}>
          <form onSubmit={onDecline}>
            <Field label="Reason (shown to reception)" htmlFor={`reason-${v.id}`} hint="Optional. Reception sees this on the live board.">
              <textarea id={`reason-${v.id}`} data-autofocus className="input" rows={3} value={text}
                aria-describedby={`reason-${v.id}-msg`} onChange={(e) => setText(e.target.value)} placeholder="e.g. Not available today" />
            </Field>
            <div className="mt-5 flex justify-end gap-2">
              <button type="button" className="btn btn-outline" onClick={close}>Cancel</button>
              <button type="submit" className="btn btn-danger">Decline visitor</button>
            </div>
          </form>
        </Modal>
      )}

      {modal === 'hold' && (
        <Modal title={`Put ${v.name} on hold`} onClose={close}>
          <form onSubmit={onHold}>
            <div role="group" aria-label="Hold duration" className="mb-3 flex flex-wrap gap-2">
              {HOLD_OPTIONS.map((o) => (
                <button key={o} type="button" data-autofocus={duration === o ? true : undefined}
                  onClick={() => setDuration(o)} className="chip px-3.5 py-1.5 text-sm" aria-pressed={duration === o}>
                  {HOLD_LABEL[o]}
                </button>
              ))}
            </div>
            {duration === 'custom' && (
              <Field label="Note for reception" htmlFor={`hold-${v.id}`} required>
                <input id={`hold-${v.id}`} className="input" value={text} onChange={(e) => setText(e.target.value)} placeholder="e.g. Free after the 3pm call" />
              </Field>
            )}
            <div className="mt-5 flex justify-end gap-2">
              <button type="button" className="btn btn-outline" onClick={close}>Cancel</button>
              <button type="submit" className="btn btn-warning" disabled={duration === 'custom' && !text.trim()}>Put on hold</button>
            </div>
          </form>
        </Modal>
      )}

      {modal === 'transfer' && (
        <Modal title={`Transfer ${v.name}`} onClose={close}>
          <form onSubmit={onTransfer} className="space-y-4">
            <Field label="Transfer to" htmlFor={`target-${v.id}`}>
              <select id={`target-${v.id}`} data-autofocus className="input" value={target} onChange={(e) => setTarget(e.target.value)}>
                {transferTargets.map((t) => <option key={t} value={t}>{ROLE_LABEL[t]}</option>)}
              </select>
            </Field>
            <Field label="Note (optional)" htmlFor={`note-${v.id}`} hint="The new host sees this note on the request.">
              <textarea id={`note-${v.id}`} className="input" rows={3} value={text} aria-describedby={`note-${v.id}-msg`}
                onChange={(e) => setText(e.target.value)} placeholder="e.g. Please handle this vendor discussion" />
            </Field>
            <div className="flex justify-end gap-2">
              <button type="button" className="btn btn-outline" onClick={close}>Cancel</button>
              <button type="submit" className="btn btn-info">Transfer to {ROLE_LABEL[target]}</button>
            </div>
          </form>
        </Modal>
      )}
    </article>
  );
}
