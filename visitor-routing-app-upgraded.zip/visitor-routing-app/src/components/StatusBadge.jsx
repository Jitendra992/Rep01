import { ArrowRightLeft, CheckCircle2, Clock, PauseCircle, XCircle } from 'lucide-react';
import { STATUS, ROLE_LABEL } from '../types';

const STYLES = {
  [STATUS.PENDING]: 'bg-ink/5 text-muted ring-line/30',
  [STATUS.ACCEPTED]: 'bg-success/15 text-success ring-success/30',
  [STATUS.DECLINED]: 'bg-danger/15 text-danger ring-danger/30',
  [STATUS.ON_HOLD]: 'bg-warning/15 text-warning ring-warning/30',
  [STATUS.TRANSFERRED]: 'bg-info/15 text-info ring-info/30',
};
const ICONS = {
  [STATUS.PENDING]: Clock,
  [STATUS.ACCEPTED]: CheckCircle2,
  [STATUS.DECLINED]: XCircle,
  [STATUS.ON_HOLD]: PauseCircle,
  [STATUS.TRANSFERRED]: ArrowRightLeft,
};

export const STATUS_LABEL = {
  [STATUS.PENDING]: 'Pending', [STATUS.ACCEPTED]: 'Accepted', [STATUS.DECLINED]: 'Declined',
  [STATUS.ON_HOLD]: 'On hold', [STATUS.TRANSFERRED]: 'Transferred',
};

/** Solid fills used by charts and legends. */
export const STATUS_BAR = {
  [STATUS.PENDING]: 'bg-muted',
  [STATUS.ACCEPTED]: 'bg-success',
  [STATUS.DECLINED]: 'bg-danger',
  [STATUS.ON_HOLD]: 'bg-warning',
  [STATUS.TRANSFERRED]: 'bg-info',
};

export function StatusBadge({ status }) {
  const Icon = ICONS[status];
  return (
    <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold ring-1 ${STYLES[status]}`}>
      {Icon && <Icon className="h-3.5 w-3.5" aria-hidden="true" />}
      {STATUS_LABEL[status]}
    </span>
  );
}

/** Receptionist-facing text for the Action/Remarks column. */
export function remarkFor(v) {
  const by = ROLE_LABEL[v.statusBy] || '';
  const timed = /^\d/.test(v.remarks || '');
  switch (v.status) {
    case STATUS.ACCEPTED: return { strong: 'Send In', text: `Accepted by ${by}` };
    case STATUS.DECLINED: return { strong: `Declined by ${by}`, text: v.remarks };
    case STATUS.ON_HOLD: return { strong: timed ? `Hold for ${v.remarks}` : 'On hold', text: timed ? `By ${by}` : `${v.remarks} (${by})` };
    case STATUS.TRANSFERRED: return { strong: `Transferred by ${by} to ${ROLE_LABEL[v.assignedTo]}`, text: `Waiting for ${ROLE_LABEL[v.assignedTo]} to confirm${v.transferNote ? ` · “${v.transferNote}”` : ''}` };
    default: return { strong: '', text: `Waiting for ${ROLE_LABEL[v.assignedTo]}` };
  }
}
