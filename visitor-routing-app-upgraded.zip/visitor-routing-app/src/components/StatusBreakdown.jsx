import { useId } from 'react';
import { STATUS } from '../types';
import { STATUS_BAR, STATUS_LABEL } from './StatusBadge';

const ORDER = [STATUS.PENDING, STATUS.ON_HOLD, STATUS.TRANSFERRED, STATUS.ACCEPTED, STATUS.DECLINED];

/** Real status distribution of the supplied visitors. */
export default function StatusBreakdown({ visitors }) {
  const id = useId();
  const total = visitors.length;
  const counts = ORDER.map((s) => ({ status: s, n: visitors.filter((v) => v.status === s).length }));
  const summary = counts.filter((c) => c.n).map((c) => `${c.n} ${STATUS_LABEL[c.status].toLowerCase()}`).join(', ');

  return (
    <section aria-labelledby={id} className="panel p-5">
      <h2 id={id} className="text-sm font-semibold">Status breakdown</h2>
      {total === 0 ? (
        <p className="mt-3 text-sm text-muted">Nothing to chart yet. Counts appear after the first check-in.</p>
      ) : (
        <>
          <div role="img" aria-label={`Status breakdown: ${summary}`} className="mt-4 flex h-2.5 gap-0.5 overflow-hidden rounded-full bg-ink/10">
            {counts.filter((c) => c.n > 0).map((c) => (
              <span key={c.status} style={{ width: `${(c.n / total) * 100}%` }} className={STATUS_BAR[c.status]} />
            ))}
          </div>
          <ul className="mt-4 space-y-2 text-sm">
            {counts.map((c) => (
              <li key={c.status} className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <span aria-hidden="true" className={`h-2.5 w-2.5 rounded-full ${STATUS_BAR[c.status]}`} />
                  {STATUS_LABEL[c.status]}
                </span>
                <span className="tabular-nums text-muted">{c.n}</span>
              </li>
            ))}
          </ul>
        </>
      )}
    </section>
  );
}
