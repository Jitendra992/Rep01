import { useCallback, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, LogOut } from 'lucide-react';
import Avatar from './Avatar';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import useDismiss from '../hooks/useDismiss';
import { ROLE_LABEL } from '../types';

export default function UserMenu() {
  const { user, logout } = useAuth();
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const close = useCallback(() => setOpen(false), []);
  useDismiss(ref, close, open);

  return (
    <div ref={ref} className="sm:relative">
      <button type="button" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-haspopup="true"
        className="flex h-10 items-center gap-2 rounded-lg pl-1 pr-1 hover:bg-ink/5 lg:pr-2">
        <Avatar name={user.name} />
        <span className="hidden text-left leading-tight lg:block">
          <span className="block max-w-[10rem] truncate text-sm font-medium">{user.name}</span>
          <span className="block text-xs text-muted">{ROLE_LABEL[user.role]}</span>
        </span>
        <ChevronDown className="hidden h-4 w-4 text-muted lg:block" aria-hidden="true" />
        <span className="sr-only">Account menu</span>
      </button>
      {open && (
        <div className="glass-strong absolute top-full z-50 mt-2 animate-pop-in rounded-xl p-2 shadow-pop max-sm:inset-x-3 sm:right-0 sm:w-72">
          <div className="px-3 py-2">
            <p className="truncate text-sm font-medium">{user.name}</p>
            <p className="truncate text-xs text-muted">{user.email}</p>
            <p className="mt-1 text-xs text-muted">Signed in as {ROLE_LABEL[user.role]}</p>
          </div>
          <div className="my-1 border-t border-line/20" />
          <button type="button" role="switch" aria-checked={theme === 'dark'} onClick={toggle}
            className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-sm hover:bg-ink/5">
            Dark theme
            <span aria-hidden="true" className={`relative h-5 w-9 rounded-full transition-colors ${theme === 'dark' ? 'bg-brand' : 'bg-ink/20'}`}>
              <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-[left] ${theme === 'dark' ? 'left-[1.1rem]' : 'left-0.5'}`} />
            </span>
          </button>
          <button type="button" onClick={() => { logout(); navigate('/login'); }}
            className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm hover:bg-ink/5">
            <LogOut className="h-4 w-4" aria-hidden="true" /> Log out
          </button>
        </div>
      )}
    </div>
  );
}
