import { useEffect } from 'react';
import Modal from './Modal';
import { StatusBadge, remarkFor } from './StatusBadge';
import { useVisitors } from '../context/VisitorContext';
import { ROLE_LABEL, fmtTime } from '../types';

/** Visitor summary plus the audit trail from the stored history. Reads live data by id. */
export default function VisitorDetails({ id, onClose }) {
  const { visitors } = useVisitors();
  const v = visitors.find((x) => x.id === id);
  useEffect(() => { if (!v) onClose(); }, [v, onClose]);
  if (!v) return null;
  const r = remarkFor(v);

  return (
    <Modal title={v.name} onClose={onClose} size="lg">
      <div className="flex flex-wrap items-center gap-2">
        <StatusBadge status={v.status} />
        <span className="text-sm text-muted">{v.phone}</span>
      </div>
      <dl className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
        <div className="sm:col-span-2"><dt className="text-muted">Agenda</dt><dd className="mt-0.5">{v.agenda}</dd></div>
        <div><dt className="text-muted">Requested host</dt><dd className="mt-0.5">{ROLE_LABEL[v.requestedHost]}</dd></div>
        <div><dt className="text-muted">Currently with</dt><dd className="mt-0.5">{ROLE_LABEL[v.assignedTo]}</dd></div>
        {(r.strong || v.remarks) && (
          <div className="sm:col-span-2"><dt className="text-muted">Latest outcome</dt>
            <dd className="mt-0.5">{r.strong && <strong className="font-semibold">{r.strong}. </strong>}{r.text}</dd></div>
        )}
      </dl>
      <h3 className="mb-3 mt-6 text-sm font-semibold">History</h3>
      <ol className="relative ml-1.5 border-l border-line/40">
        {[...v.history].reverse().map((h, i) => (
          <li key={`${h.at}-${i}`} className="relative pb-4 pl-5 last:pb-0">
            <span aria-hidden="true" className="absolute -left-[5px] top-1.5 h-2.5 w-2.5 rounded-full bg-brand ring-4 ring-surface" />
            <p className="text-sm font-medium">{h.action}</p>
            <p className="text-xs text-muted">by {ROLE_LABEL[h.by] || h.by}, {fmtTime(h.at)}</p>
            {h.note && <p className="mt-0.5 text-sm text-muted">“{h.note}”</p>}
          </li>
        ))}
      </ol>
    </Modal>
  );
}
