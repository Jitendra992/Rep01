import { useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';

/** Read/write one URL query param (used for list search so results are linkable). */
export default function useQueryParam(name) {
  const [params, setParams] = useSearchParams();
  const value = params.get(name) || '';
  const setValue = useCallback((next) => {
    setParams((prev) => {
      const n = new URLSearchParams(prev);
      if (next) n.set(name, next); else n.delete(name);
      return n;
    }, { replace: true });
  }, [name, setParams]);
  return [value, setValue];
}
