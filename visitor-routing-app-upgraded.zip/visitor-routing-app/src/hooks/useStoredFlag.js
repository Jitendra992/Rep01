import { useCallback, useState } from 'react';

/** Boolean UI preference persisted in localStorage (falls back to memory if storage is blocked). */
export default function useStoredFlag(key, initial = false) {
  const [value, setValue] = useState(() => {
    try {
      const s = localStorage.getItem(key);
      return s === null ? initial : s === '1';
    } catch { return initial; }
  });
  const set = useCallback((next) => {
    setValue(next);
    try { localStorage.setItem(key, next ? '1' : '0'); } catch { /* storage unavailable */ }
  }, [key]);
  return [value, set];
}
