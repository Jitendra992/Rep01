import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { Building2, Eye, EyeOff, LogIn } from 'lucide-react';
import Field from '../components/Field';
import ThemeToggle from '../components/ThemeToggle';
import { useAuth } from '../context/AuthContext';
import { ROLE_LABEL, ROLE_PATH, USERS } from '../types';

const STEPS = [
  'Reception checks the visitor in and picks a host.',
  'The host accepts, declines, holds, or transfers the request.',
  'Reception sees the answer on the live board.',
];

export default function Login() {
  const { user, login, demoLogin } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');

  if (user) return <Navigate to={ROLE_PATH[user.role]} replace />;

  const go = (res) => (res.ok ? navigate(ROLE_PATH[res.user.role], { replace: true }) : setError(res.error));

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <div className="absolute right-4 top-4 z-10"><ThemeToggle /></div>

      <section className="nav-shell hidden flex-col justify-between p-12 lg:flex" aria-label="About Front Desk">
        <div className="flex items-center gap-3 text-white">
          <span aria-hidden="true" className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-400 to-indigo-600 shadow-lg shadow-indigo-900/40">
            <Building2 className="h-5 w-5" />
          </span>
          <span className="text-lg font-semibold">Front Desk</span>
        </div>
        <div>
          <p className="max-w-md text-4xl font-semibold leading-tight tracking-tight text-white">Send every visitor to the right executive, without the phone calls.</p>
          <ol className="mt-8 max-w-md space-y-4 text-slate-300">
            {STEPS.map((s, i) => (
              <li key={s} className="flex gap-3">
                <span aria-hidden="true" className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/10 text-xs font-semibold text-white">{i + 1}</span>
                <span className="text-sm leading-6">{s}</span>
              </li>
            ))}
          </ol>
        </div>
        <p className="text-xs text-slate-400">Visitor data is shared between open tabs on this device.</p>
      </section>

      <main className="flex items-center justify-center p-4 sm:p-8">
        <div className="glass w-full max-w-md rounded-2xl p-6 sm:p-8">
          <div className="mb-6 flex items-center gap-2 text-lg font-semibold lg:hidden">
            <Building2 className="h-6 w-6 text-brand" aria-hidden="true" />Front Desk
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Sign in</h1>
          <p className="mb-6 mt-1 text-sm text-muted">Route visitors to the right executive.</p>
          <form onSubmit={(e) => { e.preventDefault(); go(login(email, password)); }} className="space-y-4">
            <Field label="Email" htmlFor="login-email" required>
              <input id="login-email" className="input" type="email" autoComplete="username" autoFocus value={email}
                onChange={(e) => { setEmail(e.target.value); setError(''); }} required />
            </Field>
            <Field label="Password" htmlFor="login-password" required>
              <div className="relative">
                <input id="login-password" className="input pr-10" type={show ? 'text' : 'password'} autoComplete="current-password" value={password}
                  onChange={(e) => { setPassword(e.target.value); setError(''); }} required aria-describedby={error ? 'login-error' : undefined} />
                <button type="button" onClick={() => setShow(!show)} aria-pressed={show} aria-label={show ? 'Hide password' : 'Show password'}
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1.5 text-muted hover:text-ink">
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </Field>
            {error && <p id="login-error" className="rounded-lg bg-danger/10 px-3 py-2 text-sm text-danger" role="alert">{error}</p>}
            <button type="submit" className="btn btn-primary w-full"><LogIn className="h-4 w-4" />Sign in</button>
          </form>
          <div className="mt-6 border-t border-line/20 pt-5">
            <p className="mb-3 text-sm font-medium">Quick demo login</p>
            <div className="grid grid-cols-2 gap-2">
              {USERS.map((u) => (
                <button key={u.id} type="button" onClick={() => go(demoLogin(u.email))} className="btn btn-outline">
                  Login as {ROLE_LABEL[u.role]}
                </button>
              ))}
            </div>
            <p className="mt-3 text-xs text-muted">Demo password for all accounts: password123</p>
          </div>
        </div>
      </main>
    </div>
  );
}
