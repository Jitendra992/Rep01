import { useMemo, useRef, useState } from 'react';
import {
  ArrowDown, ArrowUp, CheckCircle2, ClipboardList, Clock, Eye, LayoutDashboard, ListChecks, Search, Trash2, UserPlus, UserRoundX, Users,
} from 'lucide-react';
import AppShell from '../components/AppShell';
import ConfirmDialog from '../components/ConfirmDialog';
import EmptyState from '../components/EmptyState';
import Field from '../components/Field';
import FilterChips from '../components/FilterChips';
import PageHeader from '../components/PageHeader';
import Pagination from '../components/Pagination';
import RecentActivity from '../components/RecentActivity';
import RelativeTime from '../components/RelativeTime';
import SearchInput from '../components/SearchInput';
import StatCard from '../components/StatCard';
import StatusBreakdown from '../components/StatusBreakdown';
import VisitorDetails from '../components/VisitorDetails';
import { StatusBadge, STATUS_LABEL, remarkFor } from '../components/StatusBadge';
import { useToast } from '../context/ToastContext';
import { useVisitors } from '../context/VisitorContext';
import useQueryParam from '../hooks/useQueryParam';
import { isToday } from '../lib/format';
import { scrollToSection } from '../lib/nav';
import { HOSTS, ROLE_LABEL, ROLES, STATUS, fmtTime } from '../types';

const NAV = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'checkin', label: 'Check in a visitor', icon: UserPlus },
  { id: 'board', label: 'Live visitor board', icon: ListChecks },
];
const EMPTY = { name: '', phone: '', agenda: '', host: ROLES.MD };
const PAGE_SIZE = 8;
const OPEN = [STATUS.PENDING, STATUS.ON_HOLD, STATUS.TRANSFERRED];

// Same rules as before: name and purpose required, phone must look like a mobile number.
const validate = (f) => {
  const e = {};
  if (!f.name.trim()) e.name = 'Enter the visitor’s name.';
  if (!/^[+\d][\d\s-]{6,}$/.test(f.phone.trim())) e.phone = 'Enter a valid mobile number: digits, spaces or dashes, at least 7 characters. A leading + is fine.';
  if (!f.agenda.trim()) e.agenda = 'Enter the purpose of the visit.';
  return e;
};

export default function ReceptionDashboard() {
  const { visitors, addVisitor, clearAll } = useVisitors();
  const toast = useToast();
  const nameRef = useRef(null);

  const [form, setForm] = useState(EMPTY);
  const [errors, setErrors] = useState({});
  const [q, setQ] = useQueryParam('q');
  const [status, setStatus] = useState('all');
  const [sort, setSort] = useState('desc');
  const [page, setPage] = useState(1);
  const [detailsId, setDetailsId] = useState(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const set = (k) => (e) => {
    setForm({ ...form, [k]: e.target.value });
    if (errors[k]) setErrors({ ...errors, [k]: undefined });
  };

  const submit = (e) => {
    e.preventDefault();
    const found = validate(form);
    setErrors(found);
    if (Object.keys(found).length) {
      document.getElementById(`ci-${Object.keys(found)[0]}`)?.focus();
      return;
    }
    addVisitor(form);
    toast.success(`${form.name.trim()} checked in. Request sent to ${ROLE_LABEL[form.host]}.`);
    setForm(EMPTY);
    nameRef.current?.focus();
  };

  const waitingFor = (h) => visitors.filter((v) => v.assignedTo === h && OPEN.includes(v.status)).length;

  const kpis = {
    today: visitors.filter((v) => isToday(v.createdAt)).length,
    waiting: visitors.filter((v) => OPEN.includes(v.status)).length,
    accepted: visitors.filter((v) => v.status === STATUS.ACCEPTED).length,
    declined: visitors.filter((v) => v.status === STATUS.DECLINED).length,
  };

  const term = q.trim().toLowerCase();
  const filtered = useMemo(() => {
    const list = visitors.filter((v) =>
      (status === 'all' || v.status === status)
      && (!term || [v.name, v.phone, v.agenda, ROLE_LABEL[v.assignedTo]].join(' ').toLowerCase().includes(term)));
    return list.sort((a, b) => (sort === 'desc' ? b.createdAt.localeCompare(a.createdAt) : a.createdAt.localeCompare(b.createdAt)));
  }, [visitors, status, term, sort]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const current = Math.min(page, pageCount);
  const rows = filtered.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);

  const options = [{ value: 'all', label: 'All', count: visitors.length }, ...Object.values(STATUS).map((s) => ({
    value: s, label: STATUS_LABEL[s], count: visitors.filter((v) => v.status === s).length,
  }))];

  const clearFilters = () => { setQ(''); setStatus('all'); setPage(1); };

  return (
    <AppShell crumb="Reception desk" nav={NAV} listSectionId="board">
      <PageHeader title="Reception desk" description="Check visitors in, route them to a host, and see the answer come back live." />

      <section id="overview" tabIndex={-1} aria-label="Overview" className="grid scroll-mt-24 gap-4 focus:outline-none sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Checked in today" value={kpis.today} icon={ClipboardList} tone="brand" hint={`${visitors.length} on the board in total`} />
        <StatCard label="Waiting for a host" value={kpis.waiting} icon={Clock} tone="warning" />
        <StatCard label="Ready to send in" value={kpis.accepted} icon={CheckCircle2} tone="success" />
        <StatCard label="Declined" value={kpis.declined} icon={UserRoundX} tone="danger" />
      </section>

      <div className="mt-6 grid gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <section id="checkin" tabIndex={-1} aria-labelledby="checkin-h" className="panel scroll-mt-24 p-5 focus:outline-none sm:p-6">
          <h2 id="checkin-h" className="text-lg font-semibold">Check in a visitor</h2>
          <p className="mt-1 text-sm text-muted">Fields marked * are required. Check-in time is recorded automatically when you send the request.</p>
          <form onSubmit={submit} noValidate className="mt-5 grid gap-5 md:grid-cols-2">
            <Field label="Visitor name" htmlFor="ci-name" required error={errors.name}>
              <input id="ci-name" ref={nameRef} className="input" autoComplete="off" value={form.name} onChange={set('name')}
                aria-required="true" aria-invalid={!!errors.name} aria-describedby={errors.name ? 'ci-name-msg' : undefined} />
            </Field>
            <Field label="Mobile number" htmlFor="ci-phone" required error={errors.phone}>
              <input id="ci-phone" className="input" type="tel" autoComplete="off" value={form.phone} onChange={set('phone')}
                aria-required="true" aria-invalid={!!errors.phone} aria-describedby={errors.phone ? 'ci-phone-msg' : undefined} />
            </Field>
            <Field label="Purpose of visit / agenda" htmlFor="ci-agenda" required error={errors.agenda} className="md:col-span-2">
              <textarea id="ci-agenda" className="input" rows={2} value={form.agenda} onChange={set('agenda')}
                aria-required="true" aria-invalid={!!errors.agenda} aria-describedby={errors.agenda ? 'ci-agenda-msg' : undefined} />
            </Field>
            <fieldset className="md:col-span-2">
              <legend className="mb-1.5 text-sm font-medium">Who are they meeting?</legend>
              <div className="grid gap-3 sm:grid-cols-3">
                {HOSTS.map((h) => {
                  const n = waitingFor(h);
                  return (
                    <label key={h} className="block cursor-pointer">
                      <input type="radio" name="host" value={h} checked={form.host === h} onChange={set('host')} className="peer sr-only" />
                      <span className="block rounded-xl border border-line/40 bg-surface/50 p-3 transition-colors hover:bg-surface/90 peer-checked:border-brand peer-checked:bg-brand/10 peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-brand">
                        <span className="flex items-center gap-2 text-sm font-medium"><Users className="h-4 w-4 text-muted" aria-hidden="true" />{ROLE_LABEL[h]}</span>
                        <span className="mt-0.5 block text-xs text-muted">{n ? `${n} waiting now` : 'No one waiting'}</span>
                      </span>
                    </label>
                  );
                })}
              </div>
            </fieldset>
            <div className="md:col-span-2">
              <button type="submit" className="btn btn-primary"><UserPlus className="h-4 w-4" />Send request to host</button>
            </div>
          </form>
        </section>

        <aside aria-label="Insights" className="space-y-6">
          <StatusBreakdown visitors={visitors} />
          <RecentActivity visitors={visitors} />
        </aside>
      </div>

      <section id="board" tabIndex={-1} aria-labelledby="board-h" className="panel mt-6 scroll-mt-24 focus:outline-none">
        <div className="flex flex-wrap items-center justify-between gap-3 p-4 sm:p-5">
          <div>
            <h2 id="board-h" className="text-lg font-semibold">Live visitor board</h2>
            <p className="text-sm text-muted tabular-nums">{filtered.length} of {visitors.length} shown</p>
          </div>
          <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto">
            <SearchInput value={q} onChange={(v) => { setQ(v); setPage(1); }} label="Search visitors" placeholder="Search name, phone or agenda" />
            {visitors.length > 0 && (
              <button type="button" className="btn btn-soft-danger" onClick={() => setConfirmClear(true)}><Trash2 className="h-4 w-4" />Clear all</button>
            )}
          </div>
        </div>
        <div className="px-4 pb-4 sm:px-5">
          <FilterChips options={options} value={status} onChange={(v) => { setStatus(v); setPage(1); }} label="Filter visitors by status" />
        </div>

        <div className="overflow-x-auto border-t border-line/20" tabIndex={0} role="region" aria-label="Visitor table, scrolls horizontally on small screens">
          <table className="w-full min-w-[880px] text-left text-sm">
            <thead className="bg-ink/[0.03] text-muted">
              <tr>
                {['Visitor', 'Phone', 'Agenda', 'Assigned host', 'Status', 'Action / remarks'].map((h) => (
                  <th key={h} scope="col" className="px-4 py-2.5 font-medium">{h}</th>
                ))}
                <th scope="col" aria-sort={sort === 'desc' ? 'descending' : 'ascending'} className="px-4 py-2.5 font-medium">
                  <button type="button" className="inline-flex items-center gap-1 hover:text-ink" onClick={() => { setSort(sort === 'desc' ? 'asc' : 'desc'); setPage(1); }}
                    aria-label={`Time, sorted ${sort === 'desc' ? 'newest first' : 'oldest first'}. Activate to reverse.`}>
                    Time {sort === 'desc' ? <ArrowDown className="h-3.5 w-3.5" aria-hidden="true" /> : <ArrowUp className="h-3.5 w-3.5" aria-hidden="true" />}
                  </button>
                </th>
                <th scope="col" className="px-4 py-2.5"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((v) => {
                const r = remarkFor(v);
                return (
                  <tr key={v.id} className="border-t border-line/15 align-top transition-colors hover:bg-ink/[0.03]">
                    <td className="px-4 py-3 font-medium">
                      <button type="button" className="text-left hover:text-brand hover:underline" onClick={() => setDetailsId(v.id)}>{v.name}</button>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">{v.phone}</td>
                    <td className="max-w-[220px] px-4 py-3">{v.agenda}</td>
                    <td className="px-4 py-3">{ROLE_LABEL[v.assignedTo]}
                      {v.assignedTo !== v.requestedHost && <div className="text-xs text-muted">Asked for {ROLE_LABEL[v.requestedHost]}</div>}</td>
                    <td className="px-4 py-3"><StatusBadge status={v.status} /></td>
                    <td className="px-4 py-3">
                      {r.strong && <div className={`font-semibold ${v.status === STATUS.ACCEPTED ? 'text-success' : ''}`}>{r.strong}</div>}
                      <div className="text-muted">{r.text}</div>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-muted">
                      <div title={fmtTime(v.createdAt)}>{fmtTime(v.createdAt)}</div>
                      <div className="text-xs"><RelativeTime iso={v.createdAt} /></div>
                    </td>
                    <td className="px-4 py-3">
                      <button type="button" className="btn-icon h-8 w-8" onClick={() => setDetailsId(v.id)} aria-label={`View history for ${v.name}`} title="View history">
                        <Eye className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {visitors.length === 0 && (
            <EmptyState icon={ListChecks} title="No visitors yet"
              action={<button type="button" className="btn btn-primary" onClick={() => { scrollToSection('checkin'); nameRef.current?.focus(); }}><UserPlus className="h-4 w-4" />Check in the first visitor</button>}>
              Visitors you check in appear here with their live status.
            </EmptyState>
          )}
          {visitors.length > 0 && filtered.length === 0 && (
            <EmptyState icon={Search} title="No visitors match"
              action={<button type="button" className="btn btn-outline" onClick={clearFilters}>Clear search and filters</button>}>
              Try a different name or status.
            </EmptyState>
          )}
        </div>
        <Pagination page={current} pageSize={PAGE_SIZE} total={filtered.length} onPage={setPage} />
      </section>

      {detailsId && <VisitorDetails id={detailsId} onClose={() => setDetailsId(null)} />}
      {confirmClear && (
        <ConfirmDialog title="Clear all visitor records?" confirmLabel="Clear all records"
          message={`This permanently removes all ${visitors.length} visitor records for every role. It can’t be undone.`}
          onCancel={() => setConfirmClear(false)}
          onConfirm={() => { clearAll(); setConfirmClear(false); setPage(1); toast.info('All visitor records cleared.'); }} />
      )}
    </AppShell>
  );
}
