const c = (name) => `rgb(var(--${name}) / <alpha-value>)`;

export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: ['selector', '[data-theme="dark"]'],
  theme: {
    extend: {
      fontFamily: { sans: ['"Instrument Sans"', 'system-ui', 'sans-serif'] },
      colors: {
        canvas: c('canvas'),
        surface: c('surface'),
        ink: c('ink'),
        muted: c('muted'),
        line: c('line'),
        brand: c('brand'),
        'brand-fg': c('brand-fg'),
        onsolid: c('on-solid'),
        success: c('success'),
        warning: c('warning'),
        danger: c('danger'),
        info: c('info'),
      },
      boxShadow: { pop: 'var(--shadow-pop)' },
      keyframes: {
        'pop-in': { from: { opacity: '0', transform: 'translateY(8px) scale(.98)' }, to: { opacity: '1', transform: 'none' } },
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'toast-in': { from: { opacity: '0', transform: 'translateY(12px)' }, to: { opacity: '1', transform: 'none' } },
      },
      animation: {
        'pop-in': 'pop-in .18s ease-out',
        'fade-in': 'fade-in .15s ease-out',
        'toast-in': 'toast-in .2s ease-out',
      },
    },
  },
  plugins: [],
};
